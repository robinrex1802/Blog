from django.db import models

# Create your models here.
class Admin(models.Model):
    username = models.CharField("username", max_length=20, null=True, blank=False)
    password = models.CharField("password", max_length=20, null=True, blank=False)

    def __str__(self):
        return self.username
    


class Register(models.Model):
    username = models.CharField("username", max_length=20, null=True, blank=False)
    email = models.CharField("email", max_length=20, null=True, blank=False)
    dob = models.DateField("Start_date", null=True, blank=False)
    password = models.CharField("password", max_length=20, null=True, blank=False)

    def __str__(self):
        return self.username
    


class Contact(models.Model):
    name = models.CharField("name",max_length=30, null=True, blank=False)
    email = models.EmailField("email", max_length=30, null=True, blank=False)
    phone = models.BigIntegerField("phone", null=True, blank=False)
    message = models.TextField(null=True, blank=False)
    
    def __str__(self):
        return self.name
    

class Category(models.Model):
    name = models.CharField("name",max_length=30, null=True, blank=False)
    description = models.TextField("description",null=True, blank=False)
    date= models.DateField("date", null=True, blank=False)
    image = models.ImageField(null=True, upload_to='media')

    def __str__(self):
        return self.name
    
class Blog(models.Model):
    name = models.CharField("name",max_length=30, null=True, blank=False)
    type = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, blank=False)
    description = models.TextField("description",null=True, blank=False)
    date= models.DateField("date", null=True, blank=False)
    image = models.ImageField(null=True, upload_to='media', blank=True)
    author = models.CharField("author",max_length=30, null=True, blank=False)
    email = models.EmailField("email", max_length=30, null=True, blank=False)
    quates = models.TextField("quates",null=True, blank=False)

    def __str__(self):
        return self.name
    
class Comment(models.Model):
    name = models.CharField("name",max_length=30, null=True, blank=False)
    email = models.EmailField("email", max_length=30, null=True, blank=False)
    phone = models.BigIntegerField("phone", null=True, blank=False)
    message = models.TextField(null=True, blank=False)
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE, null=True, blank=False)

    def __str__(self):  
        return self.name
    