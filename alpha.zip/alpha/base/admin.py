from django.contrib import admin
import base.models as models



# Register your models here.
admin.site.register(models.Admin)
admin.site.register(models.Register)
admin.site.register(models.Contact)
admin.site.register(models.Category)
admin.site.register(models.Blog)
admin.site.register(models.Comment)
# Compare this snippet from base/views.py: