from rest_framework import routers
from django.contrib import admin
from django.urls import path, include
from .views import *

routers = routers.DefaultRouter()
routers.register("admin", AdminView, basename='admin')    
routers.register("register", RegisterView, basename='register')
routers.register("contact", ContactView, basename='contact')
routers.register("category", CategoryView, basename='category')
routers.register("blog", BlogView, basename='blog')
routers.register("comment", CommentView, basename='comment')    

urlpatterns = [
    path("api/", include(routers.urls)),
]
